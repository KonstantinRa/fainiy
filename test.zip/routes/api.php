<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\ChangePasswordController;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\ClientController;
use App\Http\Controllers\Admin\StaffController;
use App\Http\Controllers\Admin\TaskController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Маршруты админ панели
Route::prefix('admin')->group(function () {
    Route::post('/register', [AdminController::class, 'store'])->name('register');
    Route::post('/login', [LoginController::class, 'login'])->name('login');

    // Маршруты открыты только для админа
    Route::middleware(['auth:sanctum','scope.admin'])->group(function () {
        Route::post('/logout', [LogoutController::class, 'logout'])->name('logout');
        Route::put('/change-password', [ChangePasswordController::class, 'changePassword'])->name('changePassword');
        Route::get('/user', [AdminController::class, 'show']);

        Route::apiResource('clients', ClientController::class);
        Route::apiResource('staff', StaffController::class);
        Route::apiResource('tasks', TaskController::class);
    });
});

// Route::apiResource('clients', ClientController::class);
