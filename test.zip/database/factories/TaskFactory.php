<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class TaskFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'title' => $this->faker->text(20),
            'description' => $this->faker->text(50),
            'tags'=> $this->faker->text(5),
            'file' => $this->faker->url(),
            'completion_date' => $this->faker->dateTime()
        ];
    }
}
