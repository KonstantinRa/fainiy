<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

class RegisterController extends Controller
{
    // Регистрация
    public static function register(Request $request)
    {
        $user = User::create(
            $request->except('password','password_confirmation') +
                ['password' => Hash::make($request->input('password'))]
        );

        return response($user, Response::HTTP_CREATED);
    }
}
