<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth as Auth;
use Symfony\Component\HttpFoundation\Response;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        if (!Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            return response('invalid credential', Response::HTTP_UNAUTHORIZED);
        }
        $jwt = Auth::user()->createToken('token', ['admin'])->plainTextToken; //Создаем token с данных пользователя
        return response(['message' => 'success','jwt'=>$jwt])
            ->withCookie(cookie(
                'jwt', // Название токена
                $jwt,
                60 * 24 //Записываем на 1 день токен в cookie
            ));
    }
}
