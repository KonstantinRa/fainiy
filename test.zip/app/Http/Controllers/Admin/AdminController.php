<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Requests\User\UpdateUserRequest;

class AdminController extends Controller
{
    // Создание администратора
    public function store(Request $request){
        $request->merge(['account_type'=>1]);
        return RegisterController::register($request);
    }

    // Получаем данные пользователя
    public function show(Request $request)
    {
        return $request->user();
    }

    // Обновляем данные пользователя
    public function update(UpdateUserRequest $request){
        $request->user()->update($request->only('first_name'));
    }
}
